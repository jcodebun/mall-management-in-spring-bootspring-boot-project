<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<style><%@include file="/WEB-INF/css/home.css"%></style>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Home</title>
</head>
<body>

<div class="container">

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel" style="margin-top: 30px">
  <div class="carousel-inner">
    <div class="carousel-item active">
       <a href="${pageContext.request.contextPath}/movieGrid">
           <img src="https://media.istockphoto.com/id/1043434654/photo/film-reels-with-retro-cinema-tickets-movie-clapper-and-red-theater-seats-on-wooden-background.jpg?b=1&s=170667a&w=0&k=20&c=IjQoE6OpNJSIOwDooYcZqgsVDibYbokZ8ZGrPeupixk="
              class="w-100 h-50"/>
            </a> 
            <h2>Book Movie</h2>
    </div>
    <div class="carousel-item">
     <a href="${pageContext.request.contextPath}/parkinglist">
              <img src="https://www.keflatwork.com/wp-content/uploads/2020/04/shutterstock_401478484.jpg"
              class="w-100 h-50"/>
              </a>
              <h2>Parking Booking</h2>
    </div>
    <div class="carousel-item">
     <a href="${pageContext.request.contextPath}/foodStallList">
              <img src="https://www.keflatwork.com/wp-content/uploads/2020/04/shutterstock_401478484.jpg"
              class="w-100 h-50"/>
              </a>
              <h2>Food Booking</h2>
    </div>
    
     <div class="carousel-item">
     <a href="${pageContext.request.contextPath}/eventList">
              <img src="https://www.keflatwork.com/wp-content/uploads/2020/04/shutterstock_401478484.jpg"
              class="w-100 h-50"/>
              </a>
              <h2>Events</h2>
    </div>
    
     <div class="carousel-item">
     <a href="${pageContext.request.contextPath}/dealList">
              <img src="https://www.keflatwork.com/wp-content/uploads/2020/04/shutterstock_401478484.jpg"
              class="w-100 h-50"/>
              </a>
              <h2>Deals</h2>
    </div>
    
     <div class="carousel-item">
     <a href="${pageContext.request.contextPath}/shopList">
              <img src="https://www.keflatwork.com/wp-content/uploads/2020/04/shutterstock_401478484.jpg"
              class="w-100 h-50"/>
              </a>
              <h2>Shops</h2>
    </div>
    
     <div class="carousel-item">
     <a href="${pageContext.request.contextPath}/jobList">
              <img src="https://www.keflatwork.com/wp-content/uploads/2020/04/shutterstock_401478484.jpg"
              class="w-100 h-50"/>
              </a>
              <h2>Jobs</h2>
    </div>
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
</body>
</html>